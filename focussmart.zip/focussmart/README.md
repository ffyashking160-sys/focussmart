# focusforge-smart-task-manager
AI-Native Smart Task &amp; Focus Manager for Students — combines intelligent task parsing, adaptive scheduling, and real-time chat assistance to help students plan, prioritize, and stay focused.
